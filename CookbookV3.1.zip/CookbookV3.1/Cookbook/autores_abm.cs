﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class Autores_abm : Form
    {
        public Autores_abm()
        {
            InitializeComponent();
        }

        private void agregar_Click(object sender, EventArgs e)
        {
            agregar_autores agregar = new agregar_autores();
            agregar.ShowDialog();
        }

        private void modificar_Click(object sender, EventArgs e)
        {
            autor_modificar modificar = new autor_modificar();
            modificar.ShowDialog();
        }

        private void Autores_abm_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            agregar_Libro agregar = new agregar_Libro();
            agregar.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            modificar_libros modificar = new modificar_libros();
            modificar.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            libros_eliminar eliminar = new libros_eliminar();
            eliminar.ShowDialog();
        }

        private void eliminar_Click(object sender, EventArgs e)
        {
            autores_eliminar eliminar = new autores_eliminar();
            eliminar.ShowDialog();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button4_Click(object sender, EventArgs e)
        {
            agregar_usuario agregar= new agregar_usuario();
            agregar.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            modificar_usuario modificar = new modificar_usuario();
            modificar.ShowDialog();
        }

        private void button6_Click(object sender, EventArgs e)
        {
            eliminar_usuario eliminar = new eliminar_usuario();
            eliminar.ShowDialog();
        }
    }
}
