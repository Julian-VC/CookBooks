﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Cookbook
{
    public partial class agregar_Libro : Form
    {
        public agregar_Libro()
        {
            InitializeComponent();
        }

        private void agregar_Libro_Load(object sender, EventArgs e)
        {

        }

        private void titulo_TextChanged(object sender, EventArgs e)
        {

        }

        private void aceptar_Click(object sender, EventArgs e)
        {
            Conexion bd = new Conexion();
            bd.consulta("INSERT INTO libros VALUES(NULL,'"+titulo.Text+"','"+categoria.Text+"','"+cant_hojas.Text+"','"+null+"','"+editorial.Text+"','"+precio.Text+"','"+año.Text+"','"+indice.Text+"','"+stock.Text+"');");
            bd.cerrarConexion();
            this.Hide();
            Autores_abm mer = new Autores_abm();
            mer.ShowDialog();
        }

        private void volver_Click(object sender, EventArgs e)
        {
            this.Hide();
            Autores_abm mer = new Autores_abm();
            mer.ShowDialog();
        }

        private void cargar_Click(object sender, EventArgs e)
        {

        }
    }
}
